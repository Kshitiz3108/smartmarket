package com.capstore.email.email.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.email.email.emails.Email;
import com.capstore.email.email.repositories.Mailrepositories;

@RestController

@RequestMapping("/api/v1/email")
public class EmailController {
	
	@Autowired
	private Mailrepositories mailrepositories;
	
	@GetMapping
	public List<Email> list(){
		return mailrepositories.findAll();
	}
	@PostMapping
	@ResponseStatus(HttpStatus.OK)
	public void create(@RequestBody Email mails) {
		mailrepositories.save(mails);
	}
}
