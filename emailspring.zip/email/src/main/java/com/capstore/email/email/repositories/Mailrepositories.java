package com.capstore.email.email.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capstore.email.email.emails.Email;

public interface Mailrepositories extends JpaRepository<Email, Long>{

}
