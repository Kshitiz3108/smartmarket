import { Component, OnInit } from '@angular/core';
import {EmailService} from '../../services/email.service';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  public emails;
  constructor(private emailService:EmailService) { }

  ngOnInit() {
  this.getEmails();
  }

  getEmails(){
    this.emailService.getEmails().subscribe(
      data=>{this.emails=data},
      err=>console.error(err),
      ()=>console.log('emails loaded')
    );
  }
}
