import { Component, OnInit } from '@angular/core';
import {EmailService} from '../../services/email.service';
import {FormGroup, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  emailform:FormGroup;
  validMessage: string="";

  constructor(private emailService:EmailService) {

   }

  ngOnInit() {
    this.emailform= new FormGroup({
      sender_name :new FormControl('',Validators.required),
      reciever_name: new FormControl('',Validators.required),
      subject_line: new FormControl('',Validators.required),
      mail_body: new FormControl('',Validators.required),
      contact: new FormControl()
      }) ;
  }

  sendmail(){
    if(this.emailform.valid){
      this.validMessage="Your mails has been successfully sent";
      this.emailService.createMail(this.emailform.value).subscribe(
        data=>{
          this.emailform.reset();
          return true;
        },
        error=>{
          return Observable.throw(error);
        }
      )
    } else{
      this.validMessage="Please fill out the form"
    }
  }
}
